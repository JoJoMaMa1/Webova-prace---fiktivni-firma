<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
 
//required files

require "PHPMailer/src/Exception.php";
require "PHPMailer/src/PHPMailer.php";
require "PHPMailer/src/SMTP.php";
function sendMail($email, $subject, $message){
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->SMTPAuth   = true;             //Enable SMTP authentication
    $mail->Host       = 'smtp.gmail.com';       //Set the SMTP server to send through
    $mail->Username   = 'autoremontbusiness@gmail.com';   //SMTP write your email
    $mail->Password   = 'vigo afvd tclc ulnj';      //SMTP password
    $mail->SMTPSecure =  PHPMAILER::ENCRYPTION_STARTTLS;            //Enable implicit SSL encryption
    $mail->Port       = 587;                                    
    $mail->setFrom($email, "autoremontdotazy"); // Sender Email and name
    $mail->addAddress('autoremontbusiness@gmail.com');     //Add a recipient email  
    $mail->addReplyTo($email, 'autoremontdotazy');
    $mail->isHTML(true);        //Set email format to HTML
    $mail->Subject = 'Message';
    $mail->Body    = $message; //email message
    $mail->AltBody = $message;
    if(!$mail->send()){
        return "";
      }else{
        return "";
      }
}