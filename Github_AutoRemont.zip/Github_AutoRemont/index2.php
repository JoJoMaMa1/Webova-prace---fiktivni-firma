<?php require("script2.php");?>
<?php 
	if(isset($_POST['submit'])){
		$response = sendMail($_POST['inputEmail'], $_POST['subject'], $_POST['inputDotaz']);
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="robots" content="nofollow, noindex">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AutoRemont</title>
    <link rel="icon" type="image" href="imgs/Log2.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="AutoRemont.css">
    <script defer src="https://kit.fontawesome.com/d6f6c35c9e.js" crossorigin="anonymous"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>

<body>
  <!--Navbar-->
  <header>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
          <a class="navbar-brand" href="#"><img class="Logo" src="imgs/Logo.png" alt="AutoRemont"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav text-end">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="#onas">O nás</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#sluzby">Služby</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#galerie">Galerie</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#recenze">Recenze</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#kontakt">Kontakt</a>
              </li>
            </ul>
              <button class="btn btn-success navbarbtn" >Potuň mi káru!</button>
          </div>
        </div>
      </nav>
</header>
    <div class="d-flex justify-content-center">      
      <!--Main Body-->
          <main class="container-fluid">
                  <!--Section 1 (intro)-->
            <section class="section1 d-flex justify-content-center row">
                <div class="col-4 align-self-center">
                    <h1>AutoRemont</h1>
                    <p> <span style="font-weight: bold;">Tuning</span> podle <span style="font-weight: bold;">Vašich</span> představ</p>
                    <button class="btn btn-success">Potuň mi káru</button>
                    <button class="btn btn-outline-dark">Služby</button>
                    <div class="carMarks row">
                        <img class="col-3" src="imgs/skoda.png" alt="Škoda">
                        <img class="col-3" src="imgs/audi.png" alt="Audi">
                        <img class="col-3" src="imgs/bmw.png" alt="BMW">
                        <img class="col-3" src="imgs/w.png" alt="Wolkswagen">
                    </div>
                </div>
                <div class="intro-img col-8">
                    <img src="imgs/intro-img.png" alt="">
                </div>
                <img class="dots" src="imgs/dots.png" alt="">
            </section>
                  <!--Section 2 (team-cards)-->            
          <section class="section2" id="onas">
            <div class="cards">
                <h1>Poznej Náš Tým!</h1>
                <div class="row row-cols-1 row-cols-md-3 g-3 d-flex justify-content-center">
                    <div class="col">
                      <a style="text-decoration: none;" href="Vojtech-Pinkas.html">
                        <div class="card card1">
                        <img src="imgs/kokot1.png" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Vojtěch Pinkas</h5>
                          <p class="card-text text-muted">"Chat-GPT 3.5"</p>
                        </div>
                      </div>
                    </a>
                    </div>
                    <div class="col">
                      <a style="text-decoration: none;" href="Josef-Koci.html">
                        <div class="card card2">
                          <img src="imgs/kokot2.png" class="card-img-top" alt="...">
                          <div class="card-body">
                            <h5 class="card-title">Josef Kočí</h5>
                            <p class="card-text text-muted">"Dopdevé"</p>
                          </div>
                        </div>
                      </a>
                    </div>
                    <div class="col">
                      <a style="text-decoration: none;" href="Angus-Grospic.html">
                        <div class="card card3">
                        <img src="imgs/kokot3.png" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Angus Grospič</h5>
                          <p class="card-text text-muted">"Auschwitz build"</p>
                        </div>
                      </div>
                      </a>
                    </div>
                  </div>
                  <img class="dots2" src="imgs/dots.png" alt="">
            </div>
          </section>
                  <!--Section 3 (Services)-->
          <section class="section3 d-flex justify-content-center  row">
            <div class="col-12 d-block justify-content-center text-center">
                <h3>Potřebujete vyměnit olej?</h3>
                <br>
                <h2>Nabízíme i servisové služby.</h2>
            </div>
            <div class="info-img col-7">
                <img src="imgs/info-img.png" alt="">
            </div>
            <div class="col-5 d-block align-self-center">
              <div>
                <h3>Potřebujete vyměnit olej?</h3>
                <h2>Nabízíme i servisové služby.</h2>
                <div>
                  <p>S více než 20 lety specializovaných zkušeností se náš zkušený tým zavázal poskytovat špičkové automobilové služby šité na míru Vašim potřebám. Naši zkušení profesionálové jsou nadšení pro poskytování nejlepších možných služeb, kombinující dlouholeté zkušenosti s přístupem zaměřeným na zákazníka. Kromě tuningu nabízíme i servis.</p>
                </div>
              </div>
                <div>
                  <button class="btn btn-success">Mám zájem</button>
                </div> 
            </div>
            <img class="dots3" src="imgs/dots.png" alt="">
          </section>
                  <!--Section 4 (Services-2-cards)-->
          <section class="section4 " id="sluzby">
            <p class="nadpis">Služby</p>
            <div class="cards container-fluid">
                <div class="row row-cols-1 g-3 d-flex justify-content-center">
                    <div class="col">
                    <div class="card card1">
                        <img src="imgs/Turbo.png" class="card-img-top" alt="...">
                        <div class="card-body">
                        <h5 class="card-title">Performance package</h5>
                        <p class="card-text">Uděláme z Vašeho vozu nařáchlý sporťák, který uslyší i hluchý</p>
                        </div>
                    </div>
                    </div>
                    <div class="col">
                    <div class="card card2">
                        <img src="imgs/Servis.png" class="card-img-top" alt="...">
                        <div class="card-body">
                        <h5 class="card-title">Car maintanance</h5>
                        <p class="card-text">Zařídíme, že Váš nechutný shitbox nasratuje v jakýchkoli podmínkách</p>
                        </div>
                    </div>
                    </div>
                    <div class="col">
                    <div class="card card3">
                        <img src="imgs/Body.png" class="card-img-top" alt="...">
                        <div class="card-body">
                        <h5 class="card-title">Bath and body work</h5>
                        <p class="card-text">Necháme si záležet, aby bylo Vaše vozidlo naleštěné a voňavé</p>
                        </div>
                    </div>
                    </div>
              </div>
              <div class="forms row">
                <h4>Máte dotaz ?</h4>
                <form action="" method="post" class="row g-2">
                  <div class="email col-2">
                    <div>
                      <label for="inputEmail" class="form-label">Email</label>
                    </div>
                    <div class="d-flex justify-content-center">
                      <input name="inputEmail" type="email" class="form-control" id="inputEmail" placeholder="@gmail.com">
                    </div>
                  </div>
                  <div class="dotaz col-4">
                    <div>
                      <label for="inputDotaz" class="form-label">Dotaz</label>
                    </div>
                    <div class="d-flex justify-content-center">
                      <input name="inputDotaz" type="text" class="form-control" id="inputDotaz">
                    </div>
                  </div>
                  <button type="submit" name="submit" id="contact-submit" class="col-2 btn btn-success">Odeslat</button>
                  <?php 
			              if(@$response == "success"){
				              ?>
					              <p class="success">Email send successfully</p>			
				              <?php
			              }else{
				              ?>
					              <p class="error"><?php echo @$response; ?></p>		
				              <?php
			              }
		              ?>
                </form>
              </div>
            </div>
            <img class="dots4" src="imgs/dots.png" alt="">
          </section>
          <!--Section 5 (Gallery)-->
          <section class="section5 " id="galerie">
            <p class="nadpis2">Prohlédněte si naše předchozí práce..</p>
            <div id="carouselGallery" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active" data-bs-interval="150000">
                  <img class="carousel-img1" src="imgs/engine.png" alt="...">
                  <img class="carousel-img2" src="imgs/wheel.png" alt="...">
                  <img class="carousel-img3" src="imgs/wipe.png" alt="...">
                </div>
                <div class="carousel-item" data-bs-interval="150000">
                  <img class="carousel-img1" src="imgs/wipe.png" alt="...">
                  <img class="carousel-img2" src="imgs/engine.png" alt="...">
                  <img class="carousel-img3" src="imgs/wheel.png" alt="...">        
                </div>
                <div class="carousel-item" data-bs-interval="150000">
                  <img class="carousel-img1" src="imgs/wheel.png" alt="...">
                  <img class="carousel-img2" src="imgs/engine.png" alt="...">
                  <img class="carousel-img3" src="imgs/wipe.png" alt="...">        
                </div>
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselGallery" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselGallery" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </section>
          <!--Section 6 (Recenze)-->
          <section class="section6 gx-0" id="recenze">
            <p class="nadpis3">Zákaznické reference</p>
            <div id="carouselRecenze" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active row" data-bs-interval="150000">
                  <div class="d-flex justify-content-center">
                    <div class="col-7 d-block justify-content-center">
                      <div>
                        <label for="zakaznik" class="label">Zákazník</label>
                        <p class="zakaznik" id="zakaznik">Petr Čálek</p>
                      </div>
                      <div class="ms">
                        <label for="auto" class="label">Auto</label>
                        <p class="auto" id="auto">Audi A3</p>
                      </div>
                      <div class="rs">
                        <label for="recenze" class="label">Recenze</label>
                        <p class="recenze" id="recenze">Chlapci chlapci... moc velké díky za přetvoření mého ohavného vozu v absolutní sleeper build který ti po sešlápnutí plynu urve hlavu</p>
                      </div>
                      <div class="hs">
                        <label for="hodnoceni" class="label">Hodnocení</label>
                        <p class="hodnoceni" id="hodnoceni"></p>
                        <p><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></p>
                      </div>
                    </div>  
                    <div class="col-5 d-flex justify-content-center">
                      <img src="imgs/calek.png" alt="">
                    </div>
                  </div>
                </div>
                <div class="carousel-item row" data-bs-interval="150000">
                  <div class="d-flex justify-content-center">
                    <div class="col-7 d-block justify-content-center">
                      <div>
                        <label for="zakaznik" class="label">Zákazník</label>
                        <p class="zakaznik" id="zakaznik">Tomáš Crkal</p>
                      </div>
                      <div class="ms">
                        <label for="auto" class="label">Auto</label>
                        <p class="auto" id="auto">Škoda Fabia</p>
                      </div>
                      <div class="rs">
                        <label for="recenze" class="label">Recenze</label>
                        <p class="recenze" id="recenze">Kurva ty zmrdi mi uřízli katalyzátor a teď ta moje vyrachtaná mrdka zní jako tank a žere jak zmrd, to jsem fakt neměl dělat</p>
                      </div>
                      <div class="hs">
                        <label for="hodnoceni" class="label">Hodnocení</label>
                        <p class="hodnoceni" id="hodnoceni"></p>
                        <p><i class="fa-solid fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i><i class="fa-regular fa-star"></i></p>
                      </div>
                    </div>  
                    <div class="col-5 d-flex justify-content-center">
                      <img src="imgs/fabia.png" alt="">
                    </div>
                  </div>
                </div>
                <div class="carousel-item row" data-bs-interval="150000">
                  <div class="d-flex justify-content-center">
                    <div class="col-7 d-block justify-content-center">
                      <div>
                        <label for="zakaznik" class="label">Zákazník</label>
                        <p class="zakaznik" id="zakaznik">Kryštof Havel</p>
                      </div>
                      <div class="ms">
                        <label for="auto" class="label">Auto</label>
                        <p class="auto" id="auto">VW Passat</p>
                      </div>
                      <div class="rs">
                        <label for="recenze" class="label">Recenze</label>
                        <p class="recenze" id="recenze">Zakoupil jsem performace package a nemohu litovat, nyní se z mého vozu kouří jak z čínské továrny a nějaká gretta mi může pofasovat kára</p>
                      </div>
                      <div class="hs">
                        <label for="hodnoceni" class="label">Hodnocení</label>
                        <p class="hodnoceni" id="hodnoceni"></p>
                        <p><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-regular fa-star"></i></p>
                      </div>
                    </div>  
                    <div class="col-5 d-flex justify-content-center">
                      <img src="imgs/pasat.png" alt="">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="d-flex justify-content-center">
              <i class="fa-solid fa-chevron-left" data-bs-target="#carouselRecenze" data-bs-slide="prev" type="button"></i><i class="fa-solid fa-chevron-right" type="button" data-bs-target="#carouselRecenze" data-bs-slide="next"></i>
            </div>
          </section>
          <!--Section 7 (Kontakt)-->
          <section class="section7 row d-flex justify-content-center" id="kontakt">
            <div class="col-4">
              <div>
                <p style="font-weight: normal;">V případě zájmu nás kontaktujte zde.</p>
                <br>
                <p><i class="fa-regular fa-envelope"></i>autoremontbusiness@gmail.com</p>
                <p><i class="fa-brands fa-instagram"></i>@auto_remontceo</p>
                <p><i class="fa-solid fa-mobile-screen"></i></i>+420 563 648 956</p>
                <br>
                <p style="font-weight: normal;">Popřípadě nás najdete zde!</p>
              </div>
            </div>
            <div class="col-6 d-flex justify-content-center">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4352.761803149495!2d15.203109814955162!3d50.02314860827978!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x470c1526a0f00763%3A0x367ff3ca26b053db!2zSmFzZWxza8OhLCAyODAgMDIgS29sw61uIDI!5e0!3m2!1sen!2scz!4v1704546564780!5m2!1sen!2scz" width="600" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </section>
        </main>
    </div>
    <footer class="gx-0 row">
      <div class="footer col-6">
      <p style="float: left; margin-left: 30%;">AutoRemont</p>
      </div>
      <div class="footer col-6">
      <p style="float: right; margin-right: 30%;">Copyright 2023</p>
      </div>
    </footer>
</body>
</html>